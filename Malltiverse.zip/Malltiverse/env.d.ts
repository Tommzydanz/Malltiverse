declare module '@env' {
    export const API_URL: string;
    export const API_KEY: string;
    export const APP_ID: string;
    export const ORG_ID: string;
    export const CURRENT_ENV: string;
}